
---------------------------------------------------------------------------
Kega Fusion v3.2 BETA (C) Steve Snake 2005
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

Encore une nouvelle mise rapide :

* Correction d'un autre bug dans le noyau du YM2612 que j'ai ajout� dans la version 3.11.
  J'ai effac� par erreur une ligne de code que je pensais �tre � la mauvaise place en m�me
  temps que je corrigeais un bug de la version 3.1. Doh.

* R��criture d'une autre partie du noyau du YM2612. Cela devrait �tre presque parfait.

* Le PWM de la 32X devrait b�n�ficier d'un volume correcte. Je n'ai pas remarqu� de saut dans 
  le son, mais si vous en avez, mettez l'option Overdrive sur Off.

* L�ger changement sur le PCM du SegaCD. Je ne sais pas si cela va faire quelque chose.

* De nombreux autres changements internes qui devrait, esp�rons le, faire que le d�codage des MP3,
  fonctionne correctement lorsque la VSync est activ�, ou que certains plugins de rendu
  assez lent sont utilis�s.

Maintenant, cette fois, je veux vraiment dire, "Prochaine mise � jour quand j'aurais plus de temps"."
En esp�rant que ce sera le plus rapidement possible (1 mois ou plus). Nous verrons.


Snake.

---------------------------------------------------------------------------
Kega Fusion v3.11 BETA (C) Steve Snake 2005
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

Une mise � jour TRES rapide...

* Correction d'un bug vraiment b�te sur le noyau YM2612 qui est apparu avec la pr�c�dente version.

* Lorsque vous utiliserez la ligne de commande "-fullscreen", cela n'alt�rera plus le param�tre
  Plein Ecran dans le fichier INI.

La derni�re version �tait inutilisable � cause d'un bug vraiment idiot dans le noyau
YM2612, c'est pour cela que j'ai rapidement sortie cette version. J'ai aussi jet� un oeil sur
le probl�me de MP3 que certaines personnes avaient, et j'ai effectu� des petits 
changements pour le mode Plein �cran. J'aurais besoin de r��crire la totalit� du code CDDA
pour vraiment percevoir des am�liorations visibles, mais ce n'est pas pour tout de suite.

Snake.

---------------------------------------------------------------------------
Kega Fusion v3.1 BETA (C) Steve Snake 2005
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

Mise � jour rapide :

* R��criture d'un grosse partie du noyau YM2612. Cela devrait maintenant
  approcher la perfection. Cependant, n'ayant pas le temps de faire un beta test, 
  j'ai pu cr�er des probl�mes...

* Correction de la bordure couleur pour la 32X.

* L�g�re alt�ration du support des MP3 - cela devrait maintenant correctement fonctionner
  avec tous les syst�mes.

* Correction de la touche Plein Ecran / Echap lorsque que c'�tait lanc� par la ligne
  de commande.

* (En esp�rant) Correction d'un probl�me de Plein Ecran au d�marrage. Ceci est d�
  pour l'instant � un probl�me avec les drivers graphique.

* L�ger changement dans le code des contr�leurs, maintenant en pressant en m�me temps 
  des touches tel que HAUT+BAS cela ne devrait plus poser de probl�mes.

Le noyau YM2612 �tait dans ma ligne de mire, et j'ai pass� 99% de mon temps libre dessus.
Je suis certain d'avoir corrig� un paquet d'autres probl�mes mais je ne m'en souviens plus ;-)

La prochaine mise � jour sortira lorsque j'aurais plus de temps libre. J'imagine que 
beaucoup de personnes me pr�pareront une TODO liste :D


Snake.

---------------------------------------------------------------------------
Kega Fusion v3.0 (Maple) BETA (C) Steve Snake 2005
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

En fait, je souhaitais ajouter de nouveaux �l�ments avant de sortir une nouvelle version, mais
vu les demandes des personnes et vu que je n'aurais pas la possibilit� de travailler dessus
avant un bon moment par rapport � ma vrai vie, je sors donc cette version qui corrige de
nombreuses bugs et comporte pas mal de petits changements.

Vous avez pu remarquer que le num�ro de version a chang� ? Quelqu'un a dit
qu'il n'essayez pas Fusion, car le num�ro de version �tait bas...
Donc, vu qu'il y a eu Kega, Lazarus, et maintenant Fusion, on en est � la version
3.0 de Kega, comprendo ? ;-)

* Correction d'un probl�me avec le PWM de la 32X lors du changement du taux d'�chantillonnage.

* Ajout de l'�mulation de la bordure en couleur de la Genesis/Megadrive, et l'option pour la d�sactiver.

* Petite correction dans le code du PAD � 6 boutons (Double Switch - merci TascoDeluxe).

* Nombreuses am�liorations pour le support de la souris Sega.

* La fen�tre de Config se souvient de la page ou vous �tiez :-)

* Retrait de la lecture des ISO/BIN pour le SegaCD - c'est le moteur des BIN/CUE
  qui s'en occupe. Vous ne remarquerez pas la diff�rence mais croyez moi, c'est bien mieux ;-)

* Correction d'un bug dans le moteur des BIN/CUE lorsque que de multiples fichiers �taient utilis�s.

* Ajout du support des MP3 dans le moteur des BIN/CUE. Et oui, cela veut dire que Fusion supporte 
  maintenant les ISO/MP3. Fusion utilises le codec de Windows et donc ne contient aucun algorythme
  d�pos�s. Vu le nombre de personnes me demandant le support de cette option, et malgr� que le fait 
  que je n'en voulais pas, elle est maintenant pr�sente.

* La VSync fonctionne maintenant en mode fen�tr�. Par contre, sachez que cela pourra sacrement ralentir
  l'�mulateur, surtout si votre moniteur n'est pas activ� pour le 50hz ou 60hz, 
  selon la r�gion du jeu avec lequel vous jouez.

* Am�liorations des modes de Timings standard et alternatif.

* Ajout du support du Pro Action Replay pour la Genesis/Megadrive.

* Ajout du support du Pro Action Replay pour la GameGear et la Master
  System.

* Ajout de l'option "Trouver un Code" pour la Pro Action Replay.

* Fusion devrait maintenant �tre compatible avec les Visual Styles de WinXP.

* Ajout du mode "Avanc�e Rapide". Si la Vsync est activ� cela ne devrait pas fonctionner...

* De nombreuses petites am�liorations.

* Correction de probl�mes mineurs affectant uniquement le SegaCD BIOS CD Player.

* Lorsque l'option "Aspect Corrig�" est d�sactiv�, le filtrage est activ�, et que vous lancez
  un jeu NTSC (USA/JAP), l'�cran sera maintenant l�g�rement �tir�. Cela fonctionne pour toutes
  les consoles. L'�tirement ne fonctionne pas pour les jeux PAL, car les TV PAL affichent plus de 
  lignes que les TV NTSC, de plus certains jeux PAL utilisent des parties d'�crans suppl�mentaires
  (Virtua Fighter 32X, par exemple). Et non, cela n'enl�vera pas compl�tement la bordure de la
  Master System. 

* 24 plugins peuvent maintenant �tre support�s. Cela devrait maintenant �tre suffisant.

* Changement de nom pour les nombreux modes de Scanlines. Les personnes les pr�f�rent ainsi.

* Fusion d�marrera maintenant en mode Plein Ecran si vous quittez l'�mulateur dans ce mode.

* D'autres trucs que j'ai oubli�s.


Encore plus de choses majeurs � faire sur Fusion, une fois que j'aurais plus de temps...


Cependant, en esp�rant que vous aimerez les ajouts de cette version et que je n'ai rien cass�.
Je pourrais commencer � documenter certains points plus pr�cis�ment, aussi
too.


Snake.

---------------------------------------------------------------------------
Kega Fusion v0.1e BETA (C) Steve Snake 2004
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

En fait, je souhaitais ajouter de nouveaux �l�ments avant de sortir une nouvelle version, mais
vu les demandes des personnes et vu que je n'aurais pas la possibilit� de travailler dessus
avant un bon moment par rapport � ma vrai vie, je sors donc cette version qui corrige de
nombreuses bugs et comporte pas mal de petits changements.

Pour �tre honn�te, j'ai oubli� la plupart des corrections que j'ai faites ;-) Cependant, voici ce dont
je me souviens :

* Correction d'un petit probl�me avec le CDD du SegaCD.

* Correction d'un probl�me avec le format VGM.

* Correction d'un probl�me de son dans le jeu "Streets of Rage".

* D�couverte d'un probl�me avec les drivers sons (Merco Stone pour les tests),
  la plupart des machines devraient pourvoir fonctionner sans passer par 
  le mode "Timing Altern�".

* Ajout de l'option "Mise en veille pendant l'attente" - N'EST PAS recommand�
  car cela peut provoquer des sauts dans le son et le saut d'image, et aussi ce n'est
  pas vraiment utile car l'�mulateur permettra de lancer les programmes automatiquement
  mais pour les personnes souhaitant voir le temps du CPU disponible dans le gestionnaire
  des t�ches, c'est maintenant faisable. Utilisez le que si vous le devez. Mais ne vous
  plaignez pas � propos de probl�mes de taux d'images ;-)

* Augmentation du nombre de plugin de rendu � 16.

* Mise � jour du syst�me de plugin de rendu pour permettre les scalers en 2x, 3x et 4x. 
  (fonctionne uniquement dans le mode graphique am�lior�).

* Les plugins de rendu peuvent �tre dans le dossier "Plugins".

* Plein d'autres corrections dont je ne me souviens pas.

Plus � venir quand je serais moins pris par ma vie normale.

Snake

---------------------------------------------------------------------------
Kega Fusion v0.1d BETA (C) Steve Snake 2004
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

Encore une rapide mise � jour :

* Correction de Turrican (Genesis).

* Am�lioration du support de la ligne de commande.

* Ajout de changement de pad � 6 boutons vers le mode de timing alternatif.

* Ajout du mode Zoom pour la Game Gear.

* Ajout de l'option "Scanlines 0%" qui est maintenant s�par� des autres options. Vous pouvez
 choisir le type de scanlines que vous souhaitez dans n'importe quel rendu.

* Changement du Power On (Allumer la console) et Soft Reset (red�marrage soft), en esp�rant que les personnes
  utiliseront le red�marrage soft quand il y en a besoin ;-)

* Ajout du param�tre "ForceFullScreen32" dans le fichier INI.


La ligne de commande fonctionne comme suit :

Fusion nomdujeu.ext [console] [country] [-fullscreen]

Les options de la console sont : -sms, -gg, -gen or -md or -32x, -scd or -mcd
Les options du pays sont : -usa -jap -eur or -auto

La console par d�faut est la Genesis/Megadrive.
Le pays par d�faut est celui qui a �t� choisi dans le fichier INI, en g�n�ral le dernier qui a
�t� utilis�.

Hormis le nom du fichier qui se trouve en premi�re position, pour toutes les autres options, il n'y 
a aucun ordre particulier et sont en option.

Lors de l'utilisation de l'option -fullscreen, la touche ESCAPE permet de quitter l'�mulateur.


Snake.

---------------------------------------------------------------------------
Kega Fusion v0.1c BETA (C) Steve Snake 2004
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

Une nouvelle mise � jour :

* Correction de Spiderman (32X).

* Correction de Joe and Mac (Genesis).

* Correction de Pirates Gold (Genesis).

* Correction de la "Barre rouge"

* Modification du code contr�leur du pad � 6 boutons.

* Support de la ligne de commande.

* Une autre petite modification dans le code graphique.

* Ajout d'une bo�te affichant un message pour le premier lancement de Fusion
  qui permet de donner des conseils pour des param�tres graphiques...


La ligne de commande fonctionne comme suit :

Fusion gamename.ext [console] [-fullscreen]

Les options de la console sont : -sms, -gg, -gen or -md, -32x, -scd or -mcd

La console par d�faut est la Genesis/Megadrive.

Lors de l'utilisation de l'option -fullscreen, la touche ESCAPE permet de quitter l'�mulateur.


C'est tout pour l'instant.



-------------------------------------------------------------------------
Kega Fusion v0.1 BETA (C) Steve Snake 2004
---------------------------------------------------------------------------

Quoi de neuf ?
--------------

ForceCompatibleGFX=1
CompatibleGFXOpt=0
EnhancedGFXOpt=1
DebugFlags=0,0,1,1

Rapide Mise � jour :

* Correction d'un probl�me qui emp�chait de d�finir la barre d'espace comme une touche.

* Modification du code graphique. Devrait maintenant fonctionner par d�faut sur plus de configurations.

* D�placement des param�tres du fichier INI en haut du fichier pour faciliter l'acc�s.

* Support de plugin de rendu.

Les trucs graphiques et l'�dition du fichier INI :

4 nouveaux modes sont maintenant disponible - par d�faut c'est plus compatible mais 
probablement plus lent. Si tout fonctionne bien, vous pouvez essayer de changer le 
param�tre EnhancedGFXOpt en le mettant sur 1 pour voir si cela fonctionne - c'est le mode
le plus rapide. Si le mode am�lior� 0 ou 1 fonctionne, vous pouvez changer le param�tre
ForceCompatibleGFX en le mettant sur 1, et ensuite essayez le param�tre CompatibleGFXOpt en le
mettant sur 0 ou 1 pour voir lequel est le plus rapide. En effet, sur certaines anciennes cartes
graphiques le mode am�lior� peut �tre un peu plus lent - si c'est le cas, vous devrez utilisez 
le mode compatible.

J'esp�re maintenant que ceci fonctionnera sur un plus grand nombre de cartes graphiques - tenez moi 
au courant :)

Snake.

Qu'est donc Fusion ?
--------------------

Fusion est le successeur logique de mon pr�c�dent �mulateur, Kega.

Il est � noter qu'il �tait pr�vu d�implanter des fonctionnalit�s, mais par manque
de temps, ces derni�res ne sont pas pr�sentes (consultez le dernier paragraphe de
ce fichier). Vous devez aussi prendre en consid�ration que le code est en version 
BETA - je n'ai pas eu le temps de le tester � fond d� au fait que le code est nouveau.
Il peut y avoir des probl�mes que je n'ai pas vu - veuillez me les signaler. J'ai aussi d�cid� 
que vous aviez attendu assez longtemps et que maintenant vous pouviez jouer avec.

Voici les caract�ristiques de Fusion :

* Emule les Sega SG-1000, SC-3000, Master System, et GameGear avec un haut
  taux de pr�cision.

* Emule la Sega MegaDrive/Genesis plus pr�cis�ment que n'importe quel autre 
  �mulateur.

* Emule le Sega MegaCD/SegaCD plus pr�cis�ment que n'importe quel autre �mulateur.

* Emule le Sega 32X lus pr�cis�ment que n'importe quel autre �mulateur. 

* Poss�de de nombreuses autres et int�ressantes fonctionnalit�s.

Suite aux diff�rentes demandes, j'ai d�cid� de conserver l'interface utilisateur.


Le fait que l'interface soit semblable � Kega, veut dire que les utilisateurs de KEGA
devrait facilement s'y retrouver.

Pour conna�tre les changements techniques et les nouvelles caract�ristiques de Fusion,
vous pourrez les consulter dans ce fichier ce qui vous permettra de voir les diff�rences
entre Fusion et Kega. Vous devez garder en t�te que je n'ai pas pu test� toutes les
fonctionnalit�s de Fusion, ce qui fait que cet �mulateur est en version BETA. Les rapports de
bugs sont les bienvenues :-)

---------------------------------------------------------------------------
L'utilisation de Fusion - les bases
---------------------------------------------------------------------------

Les options de bases devraient s'expliquer d'elles m�mes, donc jusqu'� ce qu'un
manuel existe, voici les informations de bases sur l'utilisation de ces derni�res.

Pour avoir plus de d�tail et en savoir plus sur les "fonctionnalit�s particuli�res", consultez la fin
de ce fichier.


Menu FICHIER
------------

Charger une ROM MasterSystem     - Charge une ROM MasterSystem/SG-1000/SC-3000

Charger une ROM GameGear         - Charge une ROM GameGear

Charger une ROM Genesis/32X      - Charge une ROM Genesis (Megadrive) ou 32X

Charger une Image SegaCD         - Charge une image SegaCD ISO,BIN,CUE ou SCD
 
D�marrer le SegaCD               - D�marre le SegaCD � partir d'un vrai CD se trouvant dans le lecteur

Red�marrage Soft                 - Red�marrage Soft de la console en cours

Eteindre la console              - Arr�te la console

Allumer la console/R. Hard       - Allume la console ou Red�marrage Hard

Game G�nie                       - Entrer / Editer / Changer les codes Game G�nie

Charger un �tat en tant que      - Charge un fichier d'�tat particulier

Sauvegarder un �tat en tant que  - Sauvegarde d'un fichier d'�tat particulier

Chargement/Sauvegarde d'�tat     - Charge ou sauvegarde vers 1 des 10 emplacements d'�tats

Changer l'emplacement d'�tat     - S�lectionne un emplacement d'�tat pour Charger/Sauvegarder

Charger une cartouche RAM        - Charge la cartouche RAM du SegaCD
 
Cr�er une nouvelle Cartouche RAM - Cr�er et charger une nouvelle cartouche RAM pour le SegaCD

Quitter                          - Quitte l'�mulateur Fusion


Menu PAYS
---------

S�lectionnez les modes USA/JAP/EUR, ou Auto d�tection. L'auto d�tection peut ne pas fonctionner
pour tous les jeux � cause de donn�e incorrecte se trouvant dans l�en-t�te de la ROM. Vous pouvez aussi choisir
l'ordre de pr�f�rence pour la d�tection du pays, pour les jeux fonctionnant dans plusieurs pays.


Menu VIDEO
----------

Ici, vous pouvez choisir (s�par�ment) la taille de la fen�tre (pour le mode fen�tr�)
et la r�solution (pour le mode plein �cran). Les options disponibles d�pendront de votre
configuration. La fen�tre est limit�e aux tailles correspondant aux sp�cifications d'une
TV standard (4:3) - alors que les r�solutions ne sont pas limit� - afin de permettre
l'affichage TFT avec des sp�cifications qui ne sont pas en 4:3, tel que le 1280x1024. 

C'est aussi dans ce menu, que vous pouvez basculer en Plein Ecran ou fen�tr�, activer/d�sactiver
la synchro vertical (VSync), et s�lectionner le mode de rendu � choisir entre Normal,
un des 4 modes Scanlines, et le mode TV.


Menu SON
--------

Dans ce menu, vous pouvez activer/d�sactiver l'�mulation du son, et choisir le taux
d'�chantillonnage.

Voici ce qui est recommand�, si votre PC est assez rapide, s�lectionnez le mode "SuperHQ".
Les chips sons  pour chaque console sont �mul�s beaucoup plus pr�cis�ment dans ce mode
et le son est tr�s proche des vrais consoles. L��chantillonnage sera aussi corrig�
lorsque vous s�lectionnez cette option en 44100Hz.

L'option OVERDRIVE double le volume de la sortie son, rendant le son plus proche que la plupart
des autres �mulateurs en utilisant le core (noyau) son de MAME. Cependant le fait 
d'avoir fait ceci, veut dire que le YM2612, et probablement d'autres chips, seront l�g�rement
distordu par moment. Si vous arr�t� cette option, et que vos haut parleurs sont activ�s,
vous aurez tr�s l�g�rement une am�lioration du son. Mais sans aucun doute les utilisateurs
pr�f�reront le mode OVERDRIVE.

Vous pouvez enregistrer la sortie son vers un fichier WAV ou un fichier VGM. S�lectionnez l'une de 
ces options, choisissez un nom de fichier pour l'enregistrer, et l'enregistrement commencera.
Pour arr�ter l'enregistrement � n'importe quel moment, res�lectionnez tout simplement la m�me option.



Menu LECTEUR
------------

Vos lecteurs de CD-ROM devraient s'afficher ici. S�lectionner le lecteur 
que vous souhaitez utiliser pour d�marrer les jeux.


Menu OPTIONS
------------

CHOISIR LA CONFIG - Consulter la section CONFIG

SYNCHRO PARFAITE - Certains jeux SegaCD/MegaCD pourront fonctionner correctement seulement si les 
2 processeurs MC8000 se trouvant dans la console sont parfaitement synchronis�s. Cette option active 
cette fonctionnalit�. Cela demande un peu plus de puissance processeur, mais vous pouvez aussi 
vouloir d�sactiver cette option si les jeux n'en ont pas l'utilit�. Malgr� le fait qu'il serait
pr�f�rable de le laisser activer tout le temps, si vous remarquer des probl�mes avec certains jeux
Mega/SegaCD, vous pouvez essayer de voir si le fait d'activer/d�sactiver l�option, cela permet de faire fonctionner
les jeux.

Vous pouvez choisir d'activer/d�sactiver l'affichage du compteur de frames per second (le compteur du nombre
d'images par secondes, et les LEDS (les lumi�res) du SegaCD.

UTILISEZ LE TIMING ALTERNATIF - Logiquement, la carte son sera utilis� pour le timing - ce qui 
devrait donner un son correct. Cependant, certaines cartes sons/drivers ne fournissent pas 
des informations sur la pr�cision du timing. Si vous notez des acc�l�rations / ralentissements ou des 
probl�mes de vitesse, vous pouvez essayer d'activer le timing alternatif.

NOTE : vous pouvez aussi avoir des probl�mes de son si vous l'utilisez. Cette option sera activ� par d�faut
si vous ne poss�dez pas de carte son ou que vous avez d�sactiv� le son.


CONFIG
------


SMS/GG :
--------

Vous pouvez d�terminer l'emplacement des fichiers BIOS USA/JAP/EUR BIOS pour la Sega
Master System, et le fichier BIOS GG de la Game Gear. Ces fichiers ne sont pas utiles, mais pouvez les utiliser si vous le souhaitez.

Les Fichiers SxM - ce sont des fichiers qui �mule la battery-backed RAM utilis�s dans
certaines cartouches de jeux. S�lectionnez le dossier ou vous voulez voir ces fichiers
sauvegard�s.

Les Fichiers d'�tats - Consultez la section CHARGER/SAUVEGARDER UN ETAT. S�lectionner le dossier
ou vous souhaitez voir ces fichiers sauvegard�s.

Vous pouvez aussi d�sactiver certaines choses qui sont pr�sentes par d�faut :

* Le limiteur de Sprite - une vrai SMS/GG peut seulement affich� un petit nombre de 
  sprites sur une ligne, et apr�s �a, le reste ne sera pas affich�. Certains jeux
  utilisent pour afficher des sprites disparu sous d'autres objets. Cependant, vous pouvez
  d�sactiver cette option et laissez tous les sprites s�afficher - pour certains jeux 
  cela enl�vera plein de scintillements.

* Utiliser le BIOS - permet d'ignorer les fichiers BIOS sans avoir besoin 
  de tous les �diter manuellement. Les jeux SG-1000/SC-3000, par exemple, ne fonctionneront
  probablement pas si les fichiers BIOS sont activ�s car ils manquent de donn�es dans les 
  fichiers BIOS pour les utiliser.

* La bordure de la SMS - certaines personnes n'appr�cient pas le fait que la zone
  se trouvant � l'ext�rieur de l'affichage de la SMS est rempli avec une "bordure de couleur".
  Vu que cette option a �t� demand�e, vous pouvez maintenant enlever cette "bordure de couleur".
  
* YM2413FM - un chip son suppl�mentaire pr�sent seulement dans les SMS japonaises. Aucun programme
  qui n'utilise pas cette fonctionnalit� ne devrait avoir acc�s � cette fonction, mais vous pouvez
  la d�sactiver si vous entendez des sons �tranges.


Genesis:
--------

Les fichiers SRM - ce sont les fichiers RAM utilis�s dans certaines cartouches. 
S�lectionnez le dossier ou vous souhaitez sauvegarder ces fichiers.

Les fichiers d'�tats - consultez CHARGER/SAUVERGARDER UN ETAT. S�lectionner le dossier ou
vous voulez sauvegarder ces fichiers.

Les fichiers Patch - ce sont les fichiers pour les codes Game G�nie. S�lectionner le dossier ou
vous voulez sauvegarder ces fichiers.

Le fichier BIOS - vous pouvez sp�cifier l'emplacement o� se trouve le fichier BIOS de la Genesis/Megadrive.
Ce fichier n'est pas utile, mais vous pouvez l'utiliser quand m�me.

Correction Auto des Checksums - Corrige les checksums sur les ROMS qui poss�dent un mauvais checksums. Certaines
ROMS sont "suppos�s" avoir de mauvais checksums. Si votre jeu plante (souvent avec un �cran rouge)
Essayez de changer cette option et rechargez la ROM.

D�sactiver la SRAM - Certains jeux poss�dent une sorte de protection qui essayera d'�crire dans la 
SRAM. La cartouche elle m�me ne poss�de pas actuellement de SRAM - donc si l'�criture est r�ussi,
le jeu ne fonctionnera pas correctement. Pugsy fait partie de ces jeux, et il peut y en avoir d'autres.


Sega CD:
--------

BIOS USA/JAP/EUR - localise les fichiers BIOS n�cessaires � l'�mulation du SegaCD.

Les fichiers BRM - S�lectionne le dossier ou vous souhaitez avoir les sauvegardes des jeux SegaCD.

ReadAhead - Cette option d�pends de la vitesse de votre PC et de votre lecteur de CD-ROM. Testez la !

RAM interne - "Par jeu" cela cr�era et sauvegardera un nouveau fichier RAM pour chaque jeu charg�.
"Simple" utilisera seulement un fichier de RAM interne, identique � la vrai console.

CD+G - Sp�cifie comment les codes CD+G sont trait�s. Ceci d�pend de votre lecteur de CD, 
et c'est seulement utile si vous lancer un CD audio contenant du code CD+G. La plupart du temps,
vous devrez laisser cette option sur Off (elle n'est pas utilis� pendant la lecture des jeux ou les Cd audio normaux, 
et peut m�me affecter les performances) mais si vous poss�der un disque CD+G, vous pouvez choisir entre les modes
RAW ou COOKED. Le fonctionnement  d�pendra de votre lecteur de CD - plein de lecteurs de CD ne fonctionnent du tout,
mais la plupart des lecteurs de CD-RW devraient supporter au moins un de ces formats.

a noter que le CD+G n�est pas tr�s fiable - les donn�es du CD+G data ne sont pas 
prot�g�es par des checksums/donn�es corrig�s comme le reste des donn�es sur un CD.
Donc si vous voyez des corruptions pendant la lecture d'un disque CD+G, ne soyez pas 
surpris ;-) Il n'y a pas grand chose � faire par rapport � �a, c'est un probl�me avec le 
format CD+G.


32X :
-----

BIOS M68K/Ma�tre/Esclave -localise les fichiers BIOS n�cessaires � l'�mulation de la 32X.

D�sactiver le 32X - A la diff�rence des autres �mulateurs qui traitent le 32X comme une
console s�par�e, dans cette �mulateur le 32X est connect� � la Genesis/Megadrive tout
le temps - comme avec les vrais consoles. Cependant, bien que cela ne devrait pas se produire,
il est possible que des programmes PEUVENT accidentellement d�clencher la 32X, ce qui ne devrait 
pas faire de mal hormis affecter les performances. Si c'est le cas, vous pouvez le d�sactiver (du moins
le d�branch�). L'autre raison de vouloir d�sactiver cette option est que certains jeux 
fonctionneront mieux avec ou sans cette option.


Contr�leurs :
-------------

Ici vous pouvez choisir le type de contr�leur qui est connect� sur chacun des ports. 
Vous pouvez aussi s�lectionner parmi les contr�leurs disponible celui que vous d�sirez
utiliser (Clavier, Joystick et dans certains la souris). Cliquez sur le bouton DEFINIR
pour choisir les touches ou les boutons du joystick.

Les contr�leurs standard support�s sont :
 - Le pad � 3 boutons.
 - Le pad � 6 boutons.
 - La souris Sega.
 - Le Menacer Sega.
La souris de votre PC peut �tre seulement utilis� pour contr�ler la souris SEGA
ou le Menacer.

Sont aussi support�s :
 - Le Teamplayer Sega (dans le port 1, le port 2, ou les deux).
 - Le 4 Way-Play de chez EA (les 2 ports sont pris).
 - Le J-Cart (utilis� par certains jeux de chez Codemasters).

Note : aucun de ces p�riph�riques ne devraient �tre activ� hormis
si un jeu le supportant en a besoin, sinon l'entr�e contr�leur pourra
ne pas fonctionner correctement.

Enfin, vous pouvez inverser la souris SEGA (n�cessaire dans certains jeux) et activer
un curseur pour le LightGun/pistolet (PAS ENCORE IMPLEMENTE), si vous le d�sirez.


---------------------------------------------------------------------------
Caract�ristiques particuli�res
---------------------------------------------------------------------------

* Vous pouvez jouer avec des jeux comportant plusieurs CD. Lorsque vous devez
  changer de disques, vous devriez apercevoir un ic�ne clignotant en bas de l'�cran
  de l'�mulateur. Cela veut dire que le lecteur de CD �mul� est OUVERT. Vous pouvez
  ainsi changer les disques sans soucis - d'un autre c�t� vous pouvez charger un 
  nouveau fichier Image SegaCD.

* Vous pouvez jouer avec un BIOS SMS en pressant "Allumer la console" lorsque l'�mulateur
  est "Arr�t�". La SMS d�marrera sans cartouche, vous permettant de jouer avec les jeux etc...
  stock�s dans le BIOS.

* Vous pouvez jouer avec une Cartouche "Flux" MegaCD en la chargeant comme une cartouche
  Genesis/Megadrive. Lorsqu'il vous dit que vous avez besoin du MegaCD pour l'utiliser, vous
  pouvez alors mettre un CD audio dans le lecteur de CD-ROM et presser sur "Lancer un CD". Le Flux
  se lancera, et restera actif jusqu'� ce que vous pressiez sur "Eteindre la console".


---------------------------------------------------------------------------
Technique
---------------------------------------------------------------------------

Fusion est principalement �crit en x86 ASM, avec des petites parties (Interface Windows,
interface DirectX, File Handling) ont �t� �crites en C. Tout le code a �t� �crit par moi
- Steve Snake.

Fusion a besoin de DirectX 7.0 ou sup�rieur, et vote bureau doit �tre soit en 16-Bit (HI-COLOR),
soit en 32-Bit (TRUE-COLOR). Des cartes graphiques r�centes sont recommand�es, cependant un mode
de compatibilit� est inclus si vous poss�der une ancienne carte, ou exp�rimenter
des probl�mes de vitesses ou autres. Cela s'activera automatiquement si n�cessaire,
mais vous pouvez le forcer en �ditant la valeur de "ForceCompatibleGFX" dans le fichier INI 
(se trouve � la fin du fichier) en le mettant sur 1. Vous pouvez aussi essayer les param�tres
� choisir entre les valeurs 0 et 1 pour l'option "CompatibleGFXOpt" pour voir lequel fonctionne
le plus rapidement sur votre configuration.

Note : ce mode n'est plus support�, de plus c'est plus lent, poss�de moins de fonctions, et n�cessite que
le bureau soit dans le mode 16-Bit (HI-COLOR).

Sous Win9x/WinME, il est n�cessaire d'avoir un gestionnaire de fichier ASPI pour
avoir acc�s aux lecteurs de CD-ROM. Sous Win2k/WinXP, l'�mulateur essayera d'utiliser l'IOCTL, 
cependant vous allez rencontrer des probl�mes avec ceci, vous pouvez �diter la valeur du 
fichier INI pour le param�tre "ForceASPI" en mettant 1, et r�installer l'ASPI.

---------------------------------------------------------------------------
Les nouvelles fonctionnalit�s
---------------------------------------------------------------------------

A partir de cette version, cette section mentionnera les changements majeurs entre Fusion et
Kega.

Il y a eu des r��critures majeures du code, mais ici, je ferais une liste des b�n�fices
de ces r��critures plut�t que de vous ennuyer avec les d�tails...

* Le syst�me vid�o a �t� grandement am�lior�.
* Fonctionne aussi en mode 32-Bit couleurs qu'en 16-Bit couleurs.
* R�solutions s�lectionnables, etc.
* Modes Scanline Multiple (c'est une demande).
* Filtres Vid�o.
* Nouveau YM2612, incluant LFO, les bugs Hardware, et d'autres fonctions.
* Synchro parfaite qui est maintenant presque aussi rapide que la version Non Synchro imparfaite.
* Le chip PCM SegaCD devrait maintenant pr�cis.
* Tous les timings SegaCD devraient maintenant �tre, ou est tr�s proche, de la pr�cision du hardware.
* L'option pour D�sactiver le son (c'est une demande)
* Fonctionne sans carte son ;)
* Support du jeu par �quipe Sega.
* Support for EA 4-Way-Play
* Support for J-Cart
* Support for Sega Mouse
* Support for Sega Menacer
* Support for CD+G (SegaCD)
* Uses IOCTL for CD-ROM access under Win2K/WinXP
* Support for the MegaCD Cartridge "Flux"
* Support for Genesis+32X
* Support for SegaCD+32X

De l�g�res am�liorations de l'�mulation de la SG-1000/SC-3000/Master System/GameGear
par rapport aux versions plus anciennes sont plus pr�cises - mais je ne peux pas faire
de commentaires par rapport aux autres �mulateurs - en effet ils sont trop nombreux ;-)
Il y a certains p�riph�riques qui ne sont pas encore support�s, ce qui veut dire
que certains jeux ne sont probablement pas jouable.

L'�mulation de la Genesis/Megadrive �tait d�j� assez pr�cise, mais avec la r��criture de 
bouts de codes, et la r��criture majeur du reverse engineering (encore !) du YM2612, 
tous les probl�mes relev�s dans les versions pr�c�dentes devrait �tre �limin�.
Ce qui nous am�ne � un total de 7 ann�es de R&D (Recherche et D�veloppement) d�vou� au YM2612, 
je peux encore choisir de r��crire le core (noyau), car je suis convaincu que je peux encore
grandement am�liorer la vitesse (il est beaucoup plus que la version pr�c�dente) - mais je me suis
surtout int�ress� � la pr�cision pour l'instant.

L'�mulation du SegaCD a �t� la pr�occupation principale de cette version, il a �t� r��crit et
tweak� presque enti�rement, et encore, plein de reverse engineering ont �t� inclus,
sur pratiquement chaque partie du syst�me, et sur les syst�mes PAL et NTSC. Il est maintenant 
beaucoup plus pr�cis et se rapproche de la vrai console comme jamais �a ne l'a �t� auparavant,
ce qui veut dire que je pourrais commencer � ajouter des choses que j'AVAIS planifi� d'ajouter dans
Kega 0.5, il y a 2 auparavant... la 32X.

L'�mulation de la 32X est TRES pr�liminaire dans cette version - mais il est d�j� vraiment pr�cis
et devrait lancer la plupart des jeux correctement. Les seuls jeux que je connaisse et qui ont des probl�mes
sont Pitfall (il semble pour l'instant buggu�, et ces probl�mes ne viendrait pas de l'�mulation) et 
Shadow Squadron (il fait des trucs �tranges, et provoque des probl�mes avec tous les �mulateurs - je vais essayer 
de voir ce qui provoque le probl�me, peut �tre qu'il se produirait sur la vrai console). 


---------------------------------------------------------------------------
Qu'est ce qui manque actuellement ?
---------------------------------------------------------------------------

* Les sauvegardes d'�tats de la 32X.
* Le faux BIOS 32X.
* Les sauvegardes d'�tats du SegaCD.
* Le contr�le de la luminosit�/Contraste ?
* Le curseur du Lightgun (Pistolet).
* Le support du Lightgun Justifier.
* Des trucs concernant la Master System.
* D'autres choses que j'ai oubli� ;)

---------------------------------------------------------------------------

C'est tout pour l'instant - passez du bon temps :-)

Snake
