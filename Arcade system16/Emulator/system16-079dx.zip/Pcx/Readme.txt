Screenshots (.PCX extensions) and YM2151 logs (.WAV extensions)
are saved here!