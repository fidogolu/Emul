Welcome to The System 16 Emulator v0.79 DirectX Port!

ABSOLUTELY READ THESE NOTES BEFORE DOING ANYTHING ELSE!!

0. You must extract this archive with a Win32-bases Unzip utility, because it contains
   long filenames! Use a utility like WinZIP or Windows Commander!
   If you don't, you will get files like SYSTEM~1.EXE, SYSTEM~1.HLP

1. SYSTEM16.DOC has been replaced by SYSTEM16DX.HLP.
   You can either double-click the HLP file from the Windows Explorer, or you can press the
   'Help'-Button in the Options-Dialog from the Emulator!

2. If this is your first download of the System 16 Emulator,
   simply extract all files of this zipfile (S16079DX.ZIP) into a 
   directory of your choice (e.g. C:\GAMES\EMULATOR\SYSTEM16)

   If you already have downloaded a previous (DOS) version of the System 16 Emulator,
   you have 2 choices: Either overwrite your existing SYSTEM16.INI file or not!
   If you don't overwrite it, you have to define the controls for the 5 new games
   by yourself. If you overwrite it, you will lose your old custom DOS settings!

   Anyway, you have to replace all other files! (especially the .GCS-files)

3. Read the HELP-FILE (SYSTEM16DX.HLP), see note #1!
   There is a STEP-BY-STEP GUIDE for First-Time-Users in it, as well as a F.A.Q.
   (Frequently asked questions)
   
4. Enjoy this release!

5. Visit the official System 16 Emulator DirectX homepage:
   http://abyss.moving-people.net/s16w32.html         [or if this one doesn't work]
   http://abyssweb.ml.org/s16w32.html

--
System 16 Arcade Emulator (c) 1996-98 Thierry Lescot, Li Jih Hwa
System 16 Arcade Emulator DirectX Port (c) 1998 Bartman/Abyss